Copyright (C) Coal Virtual Machine. All rights reserved.

Coalvm is a high-level interactive Command-Line Interface that comes
with immense amount of abstraction under the hood.

Coalvm were currently within heavy-development and stable versions,
for Coalvm prompts, you must explicitly type /CLI_HELP; inside the
CLI.